package ETC;

public class User {
    public int coins=200;
    public int level=1;
    public String name;
    public User(String name,int coins,int level)
    {
        this.name=name;
        this.coins=coins;
        this.level=level;
    }
}
