package GUI;

import javax.swing.*;

public class MyPanel extends JPanel {






}
