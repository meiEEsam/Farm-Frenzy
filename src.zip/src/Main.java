import ETC.SqlHandling;
import GUI.GUIEntrance;

public class Main {

    public static void main(String[] args) {

        new GUIEntrance();


    }

}
