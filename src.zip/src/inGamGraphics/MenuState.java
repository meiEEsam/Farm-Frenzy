package inGamGraphics;

import java.awt.*;

public class MenuState extends State{
    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics graphics) {

    }
}
